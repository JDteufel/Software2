package co.edu.poli.ejemplo1.controlador;

import co.edu.poli.ejemplo1.modelo.Proveedor;
import co.edu.poli.ejemplo1.modelo.ProveedorBuilder;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;

public class ControladorProveedor {
    @FXML
    private Button bttOk;

    @FXML
    private RadioButton selCertif, selEvalua, selPolEntr;

    @FXML
    private TextField txtCertif, txtEvalua, txtPolEntr;
    
    private ProveedorBuilder builder = new ProveedorBuilder();
    
    @FXML
    void selCertif(ActionEvent event) {
        if (selCertif.isSelected()) {
            builder.setCertificacion(txtCertif.getText());
        }
    }
    
    @FXML
    void selEvalua(ActionEvent event) {
        if (selEvalua.isSelected()) {
            builder.setEvaluacion(txtEvalua.getText());
        }
    }
    
    @FXML
    void selPolEntr(ActionEvent event) {
        if (selPolEntr.isSelected()) {
            builder.setPoliticaEntrega(txtPolEntr.getText());
        }
    }
    
    @FXML
    void bttOk(ActionEvent event) {
        Proveedor proveedor = builder.getProduct();
        
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Información del Proveedor");
        alert.setHeaderText("Datos del Proveedor Generado");
        alert.setContentText(proveedor.toString());
        alert.showAndWait();
    }
}