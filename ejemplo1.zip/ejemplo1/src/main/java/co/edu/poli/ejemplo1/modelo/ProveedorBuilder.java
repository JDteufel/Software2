package co.edu.poli.ejemplo1.modelo;

public class ProveedorBuilder implements Builder2 {
	
	private Proveedor proveedor;

    public ProveedorBuilder() {
        this.reset();
    }

    @Override
    public void reset() {
        this.proveedor = new Proveedor();
    }

    @Override
    public void setEvaluacion(String evaluacion) {
        this.proveedor.setEvaluacion(evaluacion);
    }

    @Override
    public void setCertificacion(String certificacion) {
        this.proveedor.setCertificacion(certificacion);
    }

    @Override
    public void setPoliticaEntrega(String politicaEntrega) {
        this.proveedor.setPoliticaEntrega(politicaEntrega);
    }

    public Proveedor getProduct() {
        Proveedor product = this.proveedor;
        this.reset();
        return product;
    }
}
