package co.edu.poli.ejemplo1.modelo;

public class Proveedor {
	
    private String evaluacion;
    private String certificacion;
    private String politicaEntrega;

    public void setEvaluacion(String evaluacion) {
        this.evaluacion = evaluacion;
    }
    
    public void setCertificacion(String certificacion) {
        this.certificacion = certificacion;
    }
    
    public void setPoliticaEntrega(String politicaEntrega) {
        this.politicaEntrega = politicaEntrega;
    }
    
    @Override
    public String toString() {
        return "Proveedor {evaluacion=" + evaluacion + ", certificacion=" + certificacion + ", politicaEntrega=" + politicaEntrega + "}";
    }
}