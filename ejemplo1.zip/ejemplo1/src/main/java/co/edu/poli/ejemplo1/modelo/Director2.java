package co.edu.poli.ejemplo1.modelo;

public class Director2 {
    public void construirProveedor(Builder builder) { 
    	
    }
}