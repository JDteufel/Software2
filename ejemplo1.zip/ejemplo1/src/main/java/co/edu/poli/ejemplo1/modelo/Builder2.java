package co.edu.poli.ejemplo1.modelo;

public interface Builder2 {
	
	public void reset();
	public void setEvaluacion(String evaluacion);
	public void setCertificacion(String certificacion);
	public void setPoliticaEntrega(String politicaEntrega);
}